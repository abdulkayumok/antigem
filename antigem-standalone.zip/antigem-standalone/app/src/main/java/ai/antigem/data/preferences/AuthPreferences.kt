package ai.antigem.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "auth_prefs")

class AuthPreferences(private val context: Context) {

    data class PcOverride(
        val pcId: String,
        val pcName: String,
        val host: String,
        val sshPort: Int,
        val user: String,
        val bridgePort: Int,
        val hubPort: Int,
        val token: String,
        val privateKey: String,
        /** JSch server_host_key list matching the host key pinned at pairing. */
        val hostKeyAlgorithms: String,
        /** The PC lets this phone's key open a shell ("Allow terminal from phone" in VS Code): checked at every connect. */
        val shellAllowed: Boolean = false,
    ) {
        val bridgeUrl get() = "http://127.0.0.1:$bridgePort"
        val hubUrl get() = "http://127.0.0.1:$hubPort"
    }

    companion object {
        val ACCESS_TOKEN = stringPreferencesKey("access_token")
        val REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        val EXPIRES_AT = androidx.datastore.preferences.core.longPreferencesKey("expires_at")
        val PROJECT_ID = stringPreferencesKey("project_id")
        val SUBSCRIPTION_TIER = stringPreferencesKey("subscription_tier")
        val USER_EMAIL = stringPreferencesKey("user_email")
        val TERMUX_SSH_HOST = stringPreferencesKey("termux_ssh_host")
        val TERMUX_SSH_PORT = stringPreferencesKey("termux_ssh_port")
        val TERMUX_SSH_USER = stringPreferencesKey("termux_ssh_user")
        val TERMUX_SSH_PASS = stringPreferencesKey("termux_ssh_pass")
        val IS_TERMINAL_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_terminal_tool_enabled")
        val AUTO_EXECUTE_TERMINAL = androidx.datastore.preferences.core.booleanPreferencesKey("auto_execute_terminal")
        val IS_WEB_SEARCH_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_web_search_tool_enabled")
        val IS_WEB_READER_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_web_reader_tool_enabled")
        val IS_CHOICES_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_choices_tool_enabled")
        val IS_FILE_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_file_tool_enabled")
        val IS_AUTOMATION_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_automation_tool_enabled")
        val IS_MATH_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_math_tool_enabled")
        val IS_INTERACTIVE_UI_TOOL_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_interactive_ui_tool_enabled")
        val CONTEXT_WINDOW_LIMIT = androidx.datastore.preferences.core.intPreferencesKey("context_window_limit")
        val SUMMARY_MODEL_ID = stringPreferencesKey("summary_model_id")
        val ENABLED_MODELS = androidx.datastore.preferences.core.stringSetPreferencesKey("enabled_models")
        val IS_DEV_MODE_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_dev_mode_enabled")
        val CHAT_FONT_SCALE = androidx.datastore.preferences.core.floatPreferencesKey("chat_font_scale")
        val WORKING_ANIMATION_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("working_animation_enabled")
        val CHAT_DIVIDERS_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("chat_dividers_enabled")
        val IS_LOCAL_TOOLS_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_local_tools_enabled")
        val IS_LOCAL_TOOLS_INSTALLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_local_tools_installed")
        val LOCAL_TOOLS_INSTALL_DATE = androidx.datastore.preferences.core.longPreferencesKey("local_tools_install_date")
        val LOCAL_TOOLS_VERSION = stringPreferencesKey("local_tools_version")
        val AGY_BRIDGE_HTTP_URL = stringPreferencesKey("agy_bridge_http_url")
        val AGY_HUB_URL = stringPreferencesKey("agy_hub_url")
        val USE_SSH_TERMINAL = androidx.datastore.preferences.core.booleanPreferencesKey("use_ssh_terminal")
        val PREFERRED_MODEL_ID = stringPreferencesKey("preferred_model_id")
        val PREFERRED_MODEL_KEY = stringPreferencesKey("preferred_model_key")
        val PREFERRED_MODEL_NAME = stringPreferencesKey("preferred_model_name")
        val APP_THEME_MODE = stringPreferencesKey("app_theme_mode") // "SYSTEM", "DARK", "LIGHT"
        val TERMINAL_FONT_SIZE = androidx.datastore.preferences.core.intPreferencesKey("terminal_font_size")
        val TERMINAL_CURSOR_STYLE = stringPreferencesKey("terminal_cursor_style")
        val TERMINAL_BUFFER_SIZE = androidx.datastore.preferences.core.intPreferencesKey("terminal_buffer_size")
        val TERMINAL_THEME = stringPreferencesKey("terminal_theme")
        val COMMAND_AUTO_EXECUTION_POLICY = stringPreferencesKey("command_auto_execution_policy")
        val COMMAND_SANDBOX_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("command_sandbox_enabled")
        val REQUIRE_APPROVAL_FOR_FILE_EDITS = androidx.datastore.preferences.core.booleanPreferencesKey("require_approval_for_file_edits")
        val DEFAULT_APPROVAL_SCOPE = stringPreferencesKey("default_approval_scope")
        val GROUP_CHATS_BY_WORKSPACE = androidx.datastore.preferences.core.booleanPreferencesKey("group_chats_by_workspace")
        val IS_FLOATING_BUBBLE_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_floating_bubble_enabled")
        val AUTO_SHOW_FLOATING_BUBBLE_ON_MINIMIZE = androidx.datastore.preferences.core.booleanPreferencesKey("auto_show_floating_bubble_on_minimize")
        val IS_FLOATING_SWITCHER_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_floating_switcher_enabled")
        val FLOATING_SWITCHER_ORIENTATION = stringPreferencesKey("floating_switcher_orientation")
        val FLOATING_SWITCHER_ITEMS = stringPreferencesKey("floating_switcher_items")
        val CHAT_HEADER_ITEMS = stringPreferencesKey("chat_header_items")
        val FLOATING_SWITCHER_AUTO_COLLAPSE_SEC = androidx.datastore.preferences.core.intPreferencesKey("floating_switcher_auto_collapse_sec")
        val FLOATING_SWITCHER_POS_X = androidx.datastore.preferences.core.floatPreferencesKey("floating_switcher_pos_x")
        val FLOATING_SWITCHER_POS_Y = androidx.datastore.preferences.core.floatPreferencesKey("floating_switcher_pos_y")
        val IS_FLOATING_DIAGNOSTICS_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_floating_diagnostics_enabled")
        val IS_NETWORK_INSPECTOR_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_network_inspector_enabled")
        val IS_FLOATING_NETWORK_INSPECTOR_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_floating_network_inspector_enabled")
        val SECURITY_TOKEN = stringPreferencesKey("security_token")
        val AGY_BRIDGE_BINARY_PATH = stringPreferencesKey("agy_bridge_binary_path")
        val AGY_BINARY_PATH = stringPreferencesKey("agy_binary_path")
        val CLAUDE_BINARY_PATH = stringPreferencesKey("claude_binary_path")
        val HAS_SEEN_TERMINAL_LAUNCHER_ONBOARDING = androidx.datastore.preferences.core.booleanPreferencesKey("has_seen_terminal_launcher_onboarding")
        val TERMINAL_LAUNCHER_STYLE = stringPreferencesKey("terminal_launcher_style") // "ANTITERM" or "TERMUX"
        val IS_TERMINAL_LAUNCHER_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("is_terminal_launcher_enabled")

        const val DEFAULT_BRIDGE_BINARY_PATH = "~/../usr/bin/agy_ide_bridge"
        const val DEFAULT_AGY_BINARY_PATH = "~/.local/bin/agy"
        /** The app's Claude Code launcher (glibc loader); Claude's updater never touches it. */
        const val DEFAULT_CLAUDE_BINARY_PATH = "~/../usr/bin/claude"
        /** Where the official OpenCode installer (and the app's own installer) puts it. */
        const val DEFAULT_OPENCODE_BINARY_PATH = "~/.opencode/bin/opencode"
        /** Codex: the Termux package (`pkg install codex`). */
        const val DEFAULT_CODEX_BINARY_PATH = "~/../usr/bin/codex"

        const val TOKEN_PREFIX = "x-ag"
        const val TOKEN_SUFFIX = "_9qx"
        const val TOKEN_LENGTH = 12

        fun buildFramedHeader(token: String): String {
            val clean = token.trim().take(TOKEN_LENGTH).padEnd(TOKEN_LENGTH, '0')
            return "$TOKEN_PREFIX$clean$TOKEN_SUFFIX"
        }

        private const val TOKEN_CHARSET = "0123456789abcdefghijklmnopqrstuvwxyz"
        private val secureRandom = java.security.SecureRandom()

        fun generateRandomToken(): String {
            val sb = StringBuilder(TOKEN_LENGTH)
            for (i in 0 until TOKEN_LENGTH) {
                sb.append(TOKEN_CHARSET[secureRandom.nextInt(TOKEN_CHARSET.length)])
            }
            return sb.toString()
        }

        /**
         * Connect to PC: while a paired PC is in use, the connection settings below come from it (Server mode through an
         * SSH tunnel to its bridge) instead of what the user saved, which stays untouched for "Use this phone".
         * Set from the preferences at start (see PcConnect.loadOverride); null = no PC in use.
         */
        @Volatile
        var pcOverride: PcOverride? = null

        @Volatile
        private var storedSecurityToken: String = ""

        var currentSecurityToken: String
            get() = pcOverride?.token?.takeIf { it.length == TOKEN_LENGTH } ?: storedSecurityToken
            set(value) { storedSecurityToken = value }

        // ---- Server mode: an extra header the reverse proxy (nginx / Apache / Caddy) in front of the server checks ----
        const val DEFAULT_EDGE_HEADER_NAME = "X-AntiGem-Key"
        const val EDGE_VALUE_LENGTH = 20
        private const val EDGE_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

        @Volatile
        var currentEdgeHeaderName: String = DEFAULT_EDGE_HEADER_NAME
        @Volatile
        var currentEdgeHeaderValue: String = ""

        fun generateEdgeHeaderValue(): String {
            val sb = StringBuilder(EDGE_VALUE_LENGTH)
            for (i in 0 until EDGE_VALUE_LENGTH) sb.append(EDGE_CHARSET[secureRandom.nextInt(EDGE_CHARSET.length)])
            return sb.toString()
        }

        /** Header names: letters, digits and dashes (no underscore: nginx drops those unless told not to). */
        fun isValidEdgeName(name: String) = name.isNotBlank() && name.length <= 64 && name.all { it.isLetterOrDigit() && it.code < 128 || it == '-' }
        fun isValidEdgeValue(value: String) = value.length in 8..200 && value.all { it.code in 33..126 && it != '"' && it != '\\' && it != '\'' }

        /** The extra proxy header to send to a server, or null when it is off (local mode, or no value set). */
        fun edgeHeader(): Pair<String, String>? {
            val n = currentEdgeHeaderName.trim()
            val v = currentEdgeHeaderValue
            return if (currentRemoteMode && !currentRemoteTunnel && n.isNotEmpty() && v.isNotEmpty()) n to v else null
        }

        val currentFramedHeader: String
            get() = buildFramedHeader(currentSecurityToken)

        // ai.antigem uses other ports than the old com.termux build (see build.gradle.kts) so both can run together
        val DEFAULT_HUB_URL = "http://127.0.0.1:${ai.antigem.BuildConfig.HUB_PORT}"
        val DEFAULT_BRIDGE_HTTP_URL = "http://127.0.0.1:${ai.antigem.BuildConfig.BRIDGE_PORT}"

        /** The defaults every install used before ports became per app; a saved copy of them follows the new default. */
        private const val LEGACY_HUB_URL = "http://127.0.0.1:1235"
        private const val LEGACY_BRIDGE_HTTP_URL = "http://127.0.0.1:1234"

        fun migrateHubUrl(url: String): String = if (url.trimEnd('/') == LEGACY_HUB_URL) DEFAULT_HUB_URL else url
        fun migrateBridgeUrl(url: String): String = if (url.trimEnd('/') == LEGACY_BRIDGE_HTTP_URL) DEFAULT_BRIDGE_HTTP_URL else url

        @Volatile
        private var storedHubUrl: String = DEFAULT_HUB_URL

        @Volatile
        private var storedBridgeHttpUrl: String = DEFAULT_BRIDGE_HTTP_URL

        var currentHubUrl: String
            get() = pcOverride?.hubUrl ?: storedHubUrl
            set(value) { storedHubUrl = value }

        var currentBridgeHttpUrl: String
            get() = pcOverride?.bridgeUrl ?: storedBridgeHttpUrl
            set(value) { storedBridgeHttpUrl = value }

        val currentBridgeWsUrl: String
            get() = toWsUrl(currentBridgeHttpUrl)

        /**
         * True when the bridge and the agents run on another machine (a VPS) that the app reaches over the
         * network and manages over SSH. Everything local to the phone (starting the bridge in the phone's own
         * Linux, the phone's file system as the project store, ...) is then switched off.
         */
        @Volatile
        private var storedRemoteModeValue: Boolean = false

        var currentRemoteMode: Boolean
            get() = pcOverride != null || storedRemoteModeValue
            set(value) { storedRemoteModeValue = value }

        /** Server mode as the user set it in Settings > Servers (a PC in use aside). */
        val storedRemoteMode: Boolean get() = storedRemoteModeValue

        /**
         * The terminal and Run configurations open a shell on the other machine over SSH: in Server mode, and with a PC in
         * use only when the PC allows it (otherwise they run in this phone's own terminal).
         */
        val remoteShell: Boolean get() = pcOverride?.shellAllowed ?: currentRemoteMode

        /**
         * Server mode through an SSH tunnel: the bridge and the hub listen only on the server's 127.0.0.1 and the app
         * forwards the same ports on this phone's 127.0.0.1 to them over the SSH connection. No open ports, no domain,
         * no reverse proxy. Only meaningful while [currentRemoteMode] is on.
         */
        @Volatile
        private var storedRemoteTunnel: Boolean = false

        var currentRemoteTunnel: Boolean
            get() = pcOverride != null || storedRemoteTunnel
            set(value) { storedRemoteTunnel = value }

        @Volatile
        private var storedSshPrivateKey: String = ""

        @Volatile
        private var storedSshKeyPassphrase: String = ""

        /** SSH private key (PEM/OpenSSH text) and its passphrase, used for the server connection when set. */
        var currentSshPrivateKey: String
            get() = pcOverride?.privateKey ?: storedSshPrivateKey
            set(value) { storedSshPrivateKey = value }

        var currentSshKeyPassphrase: String
            get() = if (pcOverride != null) "" else storedSshKeyPassphrase
            set(value) { storedSshKeyPassphrase = value }

        /**
         * Turns what the user typed into a base URL: `a.xyz.com` -> `http://a.xyz.com:<defaultPort>`,
         * `https://a.xyz.com` stays on 443, `1.2.3.4:9000` -> `http://1.2.3.4:9000`, a trailing path is kept
         * (reverse proxy under a sub path) and a trailing slash dropped. Returns null when it is not a usable address.
         */
        fun normalizeServerUrl(raw: String, defaultPort: Int): String? {
            var text = raw.trim()
            if (text.isEmpty()) return null
            val hasScheme = text.startsWith("http://", ignoreCase = true) || text.startsWith("https://", ignoreCase = true)
            if (text.contains("://") && !hasScheme) return null
            if (!hasScheme) text = "http://$text"
            val uri = try { java.net.URI(text) } catch (_: Exception) { return null }
            val scheme = uri.scheme?.lowercase() ?: return null
            val host = uri.host?.takeIf { it.isNotBlank() } ?: return null
            if (uri.userInfo != null) return null
            val portPart = when {
                uri.port > 0 -> ":${uri.port}"
                !hasScheme -> ":$defaultPort"
                else -> ""
            }
            val hostPart = if (host.contains(":") && !host.startsWith("[")) "[$host]" else host
            val path = (uri.rawPath ?: "").trimEnd('/')
            return "$scheme://$hostPart$portPart$path"
        }

        /** Host part of a saved server URL (for the SSH default and for display). */
        fun hostOf(url: String): String = try {
            java.net.URI(url).host.orEmpty().removePrefix("[").removeSuffix("]")
        } catch (_: Exception) { "" }

        /**
         * Attachment/artifact addresses saved while the bridge was on this phone point at 127.0.0.1; once the bridge is
         * on a server they must go to the server. Anything else is returned unchanged.
         */
        fun rebaseBridgeUrl(url: String): String {
            val uri = runCatching { java.net.URI(url) }.getOrNull() ?: return url
            val host = uri.host ?: return url
            if (!isLoopbackHost(host)) return url
            val bridge = currentBridgeHttpUrl.trimEnd('/')
            if (isLoopbackHost(hostOf(bridge))) return url
            val tail = (uri.rawPath ?: "") + (uri.rawQuery?.let { "?$it" } ?: "")
            return bridge + tail
        }

        /** True when [url] points at the configured bridge (its files need the security header). */
        fun isBridgeUrl(url: String): Boolean {
            val a = runCatching { java.net.URI(url) }.getOrNull() ?: return false
            val b = runCatching { java.net.URI(currentBridgeHttpUrl) }.getOrNull() ?: return false
            val portA = if (a.port > 0) a.port else if (a.scheme == "https") 443 else 80
            val portB = if (b.port > 0) b.port else if (b.scheme == "https") 443 else 80
            return a.host.equals(b.host, ignoreCase = true) && portA == portB
        }

        /** The bridge is on another machine (Remote mode, or any non-loopback address): use network-grade timeouts. */
        fun isRemoteEndpoint(): Boolean =
            currentRemoteMode || !isLoopbackHost(hostOf(currentBridgeHttpUrl)) || !isLoopbackHost(hostOf(currentHubUrl))

        fun isLoopbackHost(host: String): Boolean {
            val h = host.lowercase()
            return h == "localhost" || h == "127.0.0.1" || h == "::1" || h == "0.0.0.0"
        }

        fun toWsUrl(httpUrl: String): String = when {
            httpUrl.startsWith("https://") -> httpUrl.replaceFirst("https://", "wss://")
            httpUrl.startsWith("http://") -> httpUrl.replaceFirst("http://", "ws://")
            else -> "ws://$httpUrl"
        }
    }

    private val syncPrefs = context.getSharedPreferences("anti_gem_sync_prefs", Context.MODE_PRIVATE)

    init {
        val savedHub = syncPrefs.getString("agy_hub_url", null)
        val savedBridgeHttp = syncPrefs.getString("agy_bridge_http_url", null)
        if (!savedHub.isNullOrBlank()) currentHubUrl = migrateHubUrl(savedHub)
        if (!savedBridgeHttp.isNullOrBlank()) currentBridgeHttpUrl = migrateBridgeUrl(savedBridgeHttp)
        val inspectorOn = syncPrefs.getBoolean("is_network_inspector_enabled", false)
        val inspectorFloating = syncPrefs.getBoolean("is_floating_network_inspector_enabled", false)
        ai.antigem.data.remote.inspector.NetworkInspectorManager.isEnabled = inspectorOn
        ai.antigem.data.remote.inspector.NetworkInspectorManager.isFloatingBubbleEnabled = inspectorFloating

        currentRemoteMode = syncPrefs.getBoolean("remote_mode", false)
        currentRemoteTunnel = syncPrefs.getBoolean("remote_tunnel", false)
        currentSshPrivateKey = syncPrefs.getString("ssh_private_key", "") ?: ""
        currentSshKeyPassphrase = syncPrefs.getString("ssh_key_passphrase", "") ?: ""

        var token = syncPrefs.getString("security_token", null)
        if (token.isNullOrBlank() || token.length != TOKEN_LENGTH) {
            token = generateRandomToken()
            syncPrefs.edit().putString("security_token", token).apply()
        }
        currentSecurityToken = token
        currentEdgeHeaderName = syncPrefs.getString("edge_header_name", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_EDGE_HEADER_NAME
        currentEdgeHeaderValue = syncPrefs.getString("edge_header_value", "") ?: ""
        // the PC in use (Connect to PC), unless one is set already: its address and token may have been refreshed since
        val pc = runCatching { ai.antigem.data.pc.PcConnect.loadOverride(syncPrefs) }.getOrNull()
        if (pc == null || pcOverride?.pcId != pc.pcId) pcOverride = pc
    }

    fun getEdgeHeaderSync(): Pair<String, String> = currentEdgeHeaderName to currentEdgeHeaderValue

    fun saveEdgeHeaderSync(name: String, value: String) {
        currentEdgeHeaderName = name.trim().ifBlank { DEFAULT_EDGE_HEADER_NAME }
        currentEdgeHeaderValue = value.trim()
        syncPrefs.edit().putString("edge_header_name", currentEdgeHeaderName).putString("edge_header_value", currentEdgeHeaderValue).commit()
    }

    val groupChatsByWorkspace: Flow<Boolean> = context.dataStore.data.map { it[GROUP_CHATS_BY_WORKSPACE] ?: false }

    val preferredModelId: Flow<String?> = context.dataStore.data.map { it[PREFERRED_MODEL_ID] }
    val preferredModelKey: Flow<String?> = context.dataStore.data.map { it[PREFERRED_MODEL_KEY] }
    val preferredModelName: Flow<String?> = context.dataStore.data.map { it[PREFERRED_MODEL_NAME] }
    val useSshTerminal: Flow<Boolean> = context.dataStore.data.map { 
        it[USE_SSH_TERMINAL] ?: false
    }
    val isLocalToolsEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_LOCAL_TOOLS_ENABLED] ?: false }
    val isLocalToolsInstalled: Flow<Boolean> = context.dataStore.data.map { it[IS_LOCAL_TOOLS_INSTALLED] ?: false }
    val localToolsInstallDate: Flow<Long?> = context.dataStore.data.map { it[LOCAL_TOOLS_INSTALL_DATE] }
    val localToolsVersion: Flow<String?> = context.dataStore.data.map { it[LOCAL_TOOLS_VERSION] }
    val agyBridgeHttpUrl: Flow<String> = context.dataStore.data.map { 
        val url = it[AGY_BRIDGE_HTTP_URL]?.let(::migrateBridgeUrl) ?: DEFAULT_BRIDGE_HTTP_URL
        currentBridgeHttpUrl = url
        pcOverride?.bridgeUrl ?: url
    }
    val agyBridgeWsUrl: Flow<String> = agyBridgeHttpUrl.map { toWsUrl(it) }
    val agyHubUrl: Flow<String> = context.dataStore.data.map { 
        val url = it[AGY_HUB_URL]?.let(::migrateHubUrl) ?: DEFAULT_HUB_URL
        currentHubUrl = url
        pcOverride?.hubUrl ?: url
    }

    val accessToken: Flow<String?> = context.dataStore.data.map { it[ACCESS_TOKEN] }
    val refreshToken: Flow<String?> = context.dataStore.data.map { it[REFRESH_TOKEN] }
    val expiresAt: Flow<Long?> = context.dataStore.data.map { it[EXPIRES_AT] }
    val projectId: Flow<String?> = context.dataStore.data.map { it[PROJECT_ID] ?: "rising-fact-p41fc" }
    val subscriptionTier: Flow<String?> = context.dataStore.data.map { it[SUBSCRIPTION_TIER] ?: "pro" }
    val userEmail: Flow<String?> = context.dataStore.data.map { it[USER_EMAIL] }

    fun getThemeModeSync(): String {
        val cached = syncPrefs.getString("app_theme_mode", null)
        if (cached != null) return cached

        // Fast fallback: parse datastore pb file directly if syncPrefs not yet populated
        try {
            val pbFile = java.io.File(context.filesDir, "datastore/auth_prefs.preferences_pb")
            if (pbFile.exists()) {
                val content = pbFile.readBytes().toString(Charsets.ISO_8859_1)
                val key = "app_theme_mode"
                val idx = content.indexOf(key)
                if (idx != -1) {
                    val sub = content.substring(idx + key.length, minOf(content.length, idx + key.length + 30))
                    val mode = when {
                        sub.contains("LIGHT") -> "LIGHT"
                        sub.contains("DARK") -> "DARK"
                        else -> "SYSTEM"
                    }
                    syncPrefs.edit().putString("app_theme_mode", mode).apply()
                    return mode
                }
            }
        } catch (_: Exception) {}

        return "DARK"
    }

    val enabledModelIds: Flow<Set<String>?> = context.dataStore.data.map { it[ENABLED_MODELS] }
    val isDevModeEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_DEV_MODE_ENABLED] ?: false }
    val chatFontScale: Flow<Float> = context.dataStore.data.map { it[CHAT_FONT_SCALE] ?: 1.0f }

    /** The Claude Code-style "working" row under a running reply; off = only the "…" dots before the first output. */
    val workingAnimationEnabled: Flow<Boolean> = context.dataStore.data.map { it[WORKING_ANIMATION_ENABLED] ?: true }

    /** Wavy-line dividers in chats: a new day ("Sat, Oct 10") and model switches ("Switched to …"). */
    val chatDividersEnabled: Flow<Boolean> = context.dataStore.data.map { it[CHAT_DIVIDERS_ENABLED] ?: true }
    val themeMode: Flow<String> = context.dataStore.data.map { prefs ->
        val mode = prefs[APP_THEME_MODE] ?: "DARK"
        if (syncPrefs.getString("app_theme_mode", null) != mode) {
            syncPrefs.edit().putString("app_theme_mode", mode).apply()
        }
        mode
    }
    fun getTerminalFontSizeSync(): Int = syncPrefs.getInt("terminal_font_size", 14)
    fun getTerminalCursorStyleSync(): String = syncPrefs.getString("terminal_cursor_style", "BAR") ?: "BAR"
    fun getTerminalBufferSizeSync(): Int = syncPrefs.getInt("terminal_buffer_size", 20000)
    fun getTerminalThemeSync(): String = syncPrefs.getString("terminal_theme", "DEFAULT") ?: "DEFAULT"

    val terminalFontSize: Flow<Int> = context.dataStore.data.map { prefs ->
        val size = prefs[TERMINAL_FONT_SIZE] ?: 14
        if (syncPrefs.getInt("terminal_font_size", 14) != size) {
            syncPrefs.edit().putInt("terminal_font_size", size).apply()
        }
        size
    }
    val terminalCursorStyle: Flow<String> = context.dataStore.data.map { prefs ->
        val style = prefs[TERMINAL_CURSOR_STYLE] ?: "BAR"
        if (syncPrefs.getString("terminal_cursor_style", null) != style) {
            syncPrefs.edit().putString("terminal_cursor_style", style).apply()
        }
        style
    }
    val terminalBufferSize: Flow<Int> = context.dataStore.data.map { prefs ->
        val size = prefs[TERMINAL_BUFFER_SIZE] ?: 20000
        if (syncPrefs.getInt("terminal_buffer_size", 20000) != size) {
            syncPrefs.edit().putInt("terminal_buffer_size", size).apply()
        }
        size
    }
    val terminalTheme: Flow<String> = context.dataStore.data.map { prefs ->
        val th = prefs[TERMINAL_THEME] ?: "DEFAULT"
        if (syncPrefs.getString("terminal_theme", null) != th) {
            syncPrefs.edit().putString("terminal_theme", th).apply()
        }
        th
    }

    // a PC in use (Connect to PC) is the SSH server; its login is this phone's key, never a password
    val termuxSshHost: Flow<String> = context.dataStore.data.map { pcOverride?.host ?: it[TERMUX_SSH_HOST] ?: "127.0.0.1" }
    val termuxSshPort: Flow<Int> = context.dataStore.data.map { pcOverride?.sshPort ?: it[TERMUX_SSH_PORT]?.toIntOrNull() ?: 8022 }
    val termuxSshUser: Flow<String> = context.dataStore.data.map { pcOverride?.user ?: it[TERMUX_SSH_USER] ?: "root" }
    val termuxSshPass: Flow<String> = context.dataStore.data.map { if (pcOverride != null) "" else it[TERMUX_SSH_PASS] ?: "root" }
    val isTerminalToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_TERMINAL_TOOL_ENABLED] ?: false }
    val isAutoExecuteTerminal: Flow<Boolean> = context.dataStore.data.map { it[AUTO_EXECUTE_TERMINAL] ?: true }

    val isWebSearchToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_WEB_SEARCH_TOOL_ENABLED] ?: true }
    val isWebReaderToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_WEB_READER_TOOL_ENABLED] ?: true }
    val isChoicesToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_CHOICES_TOOL_ENABLED] ?: true }
    val isFileToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_FILE_TOOL_ENABLED] ?: false }
    val isAutomationToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_AUTOMATION_TOOL_ENABLED] ?: false }
    val isMathToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_MATH_TOOL_ENABLED] ?: true }
    val isInteractiveUiToolEnabled: Flow<Boolean> = context.dataStore.data.map { it[IS_INTERACTIVE_UI_TOOL_ENABLED] ?: false }
    val contextWindowLimit: Flow<Int> = context.dataStore.data.map { it[CONTEXT_WINDOW_LIMIT] ?: 10 }
    val summaryModelId: Flow<String> = context.dataStore.data.map { it[SUMMARY_MODEL_ID] ?: "always_ask" }

    val commandAutoExecutionPolicy: Flow<String> = context.dataStore.data.map {
        it[COMMAND_AUTO_EXECUTION_POLICY] ?: "CASCADE_COMMANDS_AUTO_EXECUTION_EAGER"
    }
    val commandSandboxEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[COMMAND_SANDBOX_ENABLED] ?: false
    }
    val requireApprovalForFileEdits: Flow<Boolean> = context.dataStore.data.map {
        it[REQUIRE_APPROVAL_FOR_FILE_EDITS] ?: false
    }
    val defaultApprovalScope: Flow<String> = context.dataStore.data.map {
        it[DEFAULT_APPROVAL_SCOPE] ?: "PERMISSION_SCOPE_ONCE"
    }

    suspend fun setWebSearchToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_WEB_SEARCH_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setWebReaderToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_WEB_READER_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setChoicesToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_CHOICES_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setFileToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_FILE_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setAutomationToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_AUTOMATION_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setMathToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_MATH_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setInteractiveUiToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_INTERACTIVE_UI_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setContextWindowLimit(limit: Int) {
        context.dataStore.edit { prefs ->
            prefs[CONTEXT_WINDOW_LIMIT] = limit
        }
    }

    suspend fun setSummaryModelId(modelId: String) {
        context.dataStore.edit { prefs ->
            prefs[SUMMARY_MODEL_ID] = modelId
        }
    }

    suspend fun setDevModeEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_DEV_MODE_ENABLED] = enabled
        }
    }

    suspend fun saveTermuxSshConfig(
        host: String,
        port: Int,
        user: String,
        pass: String,
        enabled: Boolean,
        autoExecute: Boolean
    ) {
        context.dataStore.edit { prefs ->
            prefs[TERMUX_SSH_HOST] = host
            prefs[TERMUX_SSH_PORT] = port.toString()
            prefs[TERMUX_SSH_USER] = user
            prefs[TERMUX_SSH_PASS] = pass
            prefs[IS_TERMINAL_TOOL_ENABLED] = enabled
            prefs[AUTO_EXECUTE_TERMINAL] = autoExecute
        }
    }

    suspend fun setTerminalToolEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_TERMINAL_TOOL_ENABLED] = enabled
        }
    }

    suspend fun setUseSshTerminal(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[USE_SSH_TERMINAL] = enabled
        }
    }

    suspend fun saveSshSettings(host: String, port: Int, user: String, pass: String) {
        context.dataStore.edit { prefs ->
            prefs[TERMUX_SSH_HOST] = host
            prefs[TERMUX_SSH_PORT] = port.toString()
            prefs[TERMUX_SSH_USER] = user
            prefs[TERMUX_SSH_PASS] = pass
        }
    }

    suspend fun setLocalToolsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_LOCAL_TOOLS_ENABLED] = enabled
        }
    }

    suspend fun setLocalToolsInstalled(installed: Boolean, version: String = "1.0.0") {
        context.dataStore.edit { prefs ->
            prefs[IS_LOCAL_TOOLS_INSTALLED] = installed
            if (installed) {
                prefs[LOCAL_TOOLS_INSTALL_DATE] = System.currentTimeMillis()
                prefs[LOCAL_TOOLS_VERSION] = version
            }
        }
    }

    suspend fun saveTokens(accessToken: String, refreshToken: String?, email: String? = null, expiresInSeconds: Long? = 3600) {
        context.dataStore.edit { prefs ->
            prefs[ACCESS_TOKEN] = accessToken
            if (refreshToken != null) {
                prefs[REFRESH_TOKEN] = refreshToken
            }
            if (email != null) {
                prefs[USER_EMAIL] = email
            }
            if (expiresInSeconds != null) {
                prefs[EXPIRES_AT] = System.currentTimeMillis() + (expiresInSeconds * 1000)
            }
        }
    }

    suspend fun saveProjectInfo(projectId: String, tier: String) {
        context.dataStore.edit { prefs ->
            prefs[PROJECT_ID] = projectId
            prefs[SUBSCRIPTION_TIER] = tier
        }
    }

    suspend fun saveEnabledModelIds(ids: Set<String>) {
        context.dataStore.edit { prefs ->
            prefs[ENABLED_MODELS] = ids
        }
    }


    suspend fun saveChatFontScale(scale: Float) {
        context.dataStore.edit { prefs ->
            prefs[CHAT_FONT_SCALE] = scale
        }
    }

    suspend fun saveWorkingAnimationEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[WORKING_ANIMATION_ENABLED] = enabled
        }
    }

    suspend fun saveChatDividersEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[CHAT_DIVIDERS_ENABLED] = enabled
        }
    }

    fun isRemoteModeSync(): Boolean = currentRemoteMode

    fun saveRemoteModeSync(enabled: Boolean) {
        currentRemoteMode = enabled
        syncPrefs.edit().putBoolean("remote_mode", enabled).commit()
    }

    fun saveRemoteTunnelSync(enabled: Boolean) {
        currentRemoteTunnel = enabled
        syncPrefs.edit().putBoolean("remote_tunnel", enabled).commit()
    }

    /** A port on the server that the app makes reachable on this phone's 127.0.0.1 over SSH (e.g. `npm run dev`). */
    data class PortForward(val serverPort: Int, val localPort: Int, val name: String, val enabled: Boolean)

    fun getPortForwardsSync(): List<PortForward> = runCatching {
        val arr = org.json.JSONArray(syncPrefs.getString("port_forwards_json", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val sp = o.optInt("server", 0)
            if (sp !in 1..65535) null
            else PortForward(sp, o.optInt("local", sp).takeIf { it in 1..65535 } ?: sp, o.optString("name"), o.optBoolean("on", true))
        }
    }.getOrDefault(emptyList())

    fun savePortForwardsSync(list: List<PortForward>) {
        val arr = org.json.JSONArray()
        list.forEach {
            arr.put(org.json.JSONObject().put("server", it.serverPort).put("local", it.localPort).put("name", it.name).put("on", it.enabled))
        }
        syncPrefs.edit().putString("port_forwards_json", arr.toString()).commit()
    }

    /** Named connection profiles the user saved by hand ("remote" = server mode, otherwise local). Stored as JSON on the phone. */
    fun listProfiles(remote: Boolean): List<org.json.JSONObject> = runCatching {
        val arr = org.json.JSONArray(syncPrefs.getString("profiles_json", "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.optBoolean("remote") == remote }
    }.getOrDefault(emptyList())

    fun saveProfile(remote: Boolean, name: String, data: org.json.JSONObject) {
        val arr = runCatching { org.json.JSONArray(syncPrefs.getString("profiles_json", "[]")) }.getOrDefault(org.json.JSONArray())
        val out = org.json.JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!(o.optBoolean("remote") == remote && o.optString("name") == name)) out.put(o)
        }
        out.put(data.put("name", name).put("remote", remote))
        syncPrefs.edit().putString("profiles_json", out.toString()).apply()
    }

    fun deleteProfile(remote: Boolean, name: String) {
        val arr = runCatching { org.json.JSONArray(syncPrefs.getString("profiles_json", "[]")) }.getOrDefault(org.json.JSONArray())
        val out = org.json.JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!(o.optBoolean("remote") == remote && o.optString("name") == name)) out.put(o)
        }
        syncPrefs.edit().putString("profiles_json", out.toString()).remove("profile_remote").remove("profile_local").apply()
    }

    fun saveSshKeySync(privateKey: String, passphrase: String) {
        currentSshPrivateKey = privateKey.trim()
        currentSshKeyPassphrase = passphrase
        syncPrefs.edit()
            .putString("ssh_private_key", currentSshPrivateKey)
            .putString("ssh_key_passphrase", passphrase)
            .commit()
    }

    /** Paths ON THE SERVER (blank = automatic: the bridge the app installs, `agy`/`claude` found by the bridge). */
    fun getRemoteBridgeBinSync(): String = syncPrefs.getString("remote_bridge_bin", "") ?: ""
    fun getRemoteAgyBinSync(): String = syncPrefs.getString("remote_agy_bin", "") ?: ""
    fun getRemoteClaudeBinSync(): String = syncPrefs.getString("remote_claude_bin", "") ?: ""
    fun getRemoteOpenCodeBinSync(): String = syncPrefs.getString("remote_opencode_bin", "") ?: ""
    fun getRemoteCodexBinSync(): String = syncPrefs.getString("remote_codex_bin", "") ?: ""

    fun saveRemoteBinariesSync(bridge: String, agy: String, claude: String, openCode: String = getRemoteOpenCodeBinSync(), codex: String = getRemoteCodexBinSync()) {
        syncPrefs.edit()
            .putString("remote_bridge_bin", bridge.trim())
            .putString("remote_agy_bin", agy.trim())
            .putString("remote_claude_bin", claude.trim())
            .putString("remote_opencode_bin", openCode.trim())
            .putString("remote_codex_bin", codex.trim())
            .apply()
    }

    /** Ports/bind the bridge LISTENS on at the server (blank = derived from the URLs). */
    fun getRemoteListenSync(): Triple<String, String, String> = Triple(
        syncPrefs.getString("remote_listen_bridge_port", "") ?: "",
        syncPrefs.getString("remote_listen_hub_port", "") ?: "",
        syncPrefs.getString("remote_listen_bind", "") ?: ""
    )

    fun saveRemoteListenSync(bridgePort: String, hubPort: String, bind: String) {
        syncPrefs.edit()
            .putString("remote_listen_bridge_port", bridgePort.trim())
            .putString("remote_listen_hub_port", hubPort.trim())
            .putString("remote_listen_bind", bind.trim())
            .apply()
    }

    /** Remote mode: let the server's `adb` reach this phone's adb daemon through an SSH reverse tunnel. */
    fun isAdbTunnelEnabledSync(): Boolean = syncPrefs.getBoolean("adb_tunnel_enabled", false)

    fun getAdbTunnelPortsSync(): Pair<Int, Int> = Pair(
        syncPrefs.getInt("adb_tunnel_connect_port", 15555),
        syncPrefs.getInt("adb_tunnel_pair_port", 15556)
    )

    fun saveAdbTunnelSync(enabled: Boolean, connectPort: Int, pairPort: Int) {
        syncPrefs.edit()
            .putBoolean("adb_tunnel_enabled", enabled)
            .putInt("adb_tunnel_connect_port", connectPort)
            .putInt("adb_tunnel_pair_port", pairPort)
            .apply()
    }

    /** Where on the server the app keeps the bridge it uploads and starts (relative to the SSH user's home). */
    fun getRemoteInstallDirSync(): String = syncPrefs.getString("remote_install_dir", ".antigem") ?: ".antigem"

    fun saveRemoteInstallDirSync(dir: String) {
        syncPrefs.edit().putString("remote_install_dir", dir.trim().ifBlank { ".antigem" }).apply()
    }

    suspend fun saveAgyHubUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed.isNotBlank()) {
            currentHubUrl = trimmed
            syncPrefs.edit().putString("agy_hub_url", trimmed).apply()
            context.dataStore.edit { prefs ->
                prefs[AGY_HUB_URL] = trimmed
            }
        }
    }

    suspend fun saveAgyBridgeHttpUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed.isNotBlank()) {
            currentBridgeHttpUrl = trimmed
            syncPrefs.edit().putString("agy_bridge_http_url", trimmed).apply()
            context.dataStore.edit { prefs ->
                prefs[AGY_BRIDGE_HTTP_URL] = trimmed
            }
        }
    }

    suspend fun saveThemeMode(mode: String) {
        syncPrefs.edit().putString("app_theme_mode", mode).commit()
        context.dataStore.edit { prefs ->
            prefs[APP_THEME_MODE] = mode
        }
    }

    suspend fun saveGroupChatsByWorkspace(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[GROUP_CHATS_BY_WORKSPACE] = enabled
        }
    }

    fun saveTerminalPreferencesSync(fontSize: Int, cursorStyle: String = "BAR", bufferSize: Int = 20000, theme: String = "DEFAULT") {
        syncPrefs.edit()
            .putInt("terminal_font_size", fontSize)
            .putString("terminal_cursor_style", cursorStyle)
            .putInt("terminal_buffer_size", bufferSize)
            .putString("terminal_theme", theme)
            .apply()
    }

    suspend fun saveTerminalPreferences(fontSize: Int, cursorStyle: String, bufferSize: Int, theme: String) {
        saveTerminalPreferencesSync(fontSize, cursorStyle, bufferSize, theme)
        context.dataStore.edit { prefs ->
            prefs[TERMINAL_FONT_SIZE] = fontSize
            prefs[TERMINAL_CURSOR_STYLE] = cursorStyle
            prefs[TERMINAL_BUFFER_SIZE] = bufferSize
            prefs[TERMINAL_THEME] = theme
        }
    }

    suspend fun savePreferredModel(modelId: String, modelKey: String = "", displayName: String = "") {
        context.dataStore.edit { prefs ->
            prefs[PREFERRED_MODEL_ID] = modelId
            if (modelKey.isNotBlank()) {
                prefs[PREFERRED_MODEL_KEY] = modelKey
            }
            if (displayName.isNotBlank()) {
                prefs[PREFERRED_MODEL_NAME] = displayName
            }
        }
    }

    suspend fun setCommandAutoExecutionPolicy(policy: String) {
        context.dataStore.edit { prefs ->
            prefs[COMMAND_AUTO_EXECUTION_POLICY] = policy
        }
    }

    suspend fun setCommandSandboxEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[COMMAND_SANDBOX_ENABLED] = enabled
        }
    }

    suspend fun setRequireApprovalForFileEdits(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[REQUIRE_APPROVAL_FOR_FILE_EDITS] = enabled
        }
    }

    suspend fun setDefaultApprovalScope(scope: String) {
        context.dataStore.edit { prefs ->
            prefs[DEFAULT_APPROVAL_SCOPE] = scope
        }
    }

    val isFloatingBubbleEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_FLOATING_BUBBLE_ENABLED] ?: true }

    fun getFloatingBubbleEnabledSync(): Boolean = syncPrefs.getBoolean("is_floating_bubble_enabled", true)

    suspend fun saveFloatingBubbleEnabled(enabled: Boolean) {
        syncPrefs.edit().putBoolean("is_floating_bubble_enabled", enabled).apply()
        context.dataStore.edit { it[IS_FLOATING_BUBBLE_ENABLED] = enabled }
    }

    val autoShowFloatingBubbleOnMinimize: Flow<Boolean> = context.dataStore.data
        .map { it[AUTO_SHOW_FLOATING_BUBBLE_ON_MINIMIZE] ?: true }

    fun getAutoShowFloatingBubbleOnMinimizeSync(): Boolean = syncPrefs.getBoolean("auto_show_floating_bubble_on_minimize", true)

    suspend fun saveAutoShowFloatingBubbleOnMinimize(enabled: Boolean) {
        syncPrefs.edit().putBoolean("auto_show_floating_bubble_on_minimize", enabled).apply()
        context.dataStore.edit { it[AUTO_SHOW_FLOATING_BUBBLE_ON_MINIMIZE] = enabled }
    }

    val isFloatingSwitcherEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_FLOATING_SWITCHER_ENABLED] ?: true }

    fun getFloatingSwitcherEnabledSync(): Boolean = syncPrefs.getBoolean("is_floating_switcher_enabled", true)

    suspend fun saveFloatingSwitcherEnabled(enabled: Boolean) {
        syncPrefs.edit().putBoolean("is_floating_switcher_enabled", enabled).apply()
        context.dataStore.edit { it[IS_FLOATING_SWITCHER_ENABLED] = enabled }
    }

    val floatingSwitcherOrientation: Flow<String> = context.dataStore.data
        .map { it[FLOATING_SWITCHER_ORIENTATION] ?: "VERTICAL" }

    fun getFloatingSwitcherOrientationSync(): String = syncPrefs.getString("floating_switcher_orientation", "VERTICAL") ?: "VERTICAL"

    suspend fun saveFloatingSwitcherOrientation(orientation: String) {
        syncPrefs.edit().putString("floating_switcher_orientation", orientation).apply()
        context.dataStore.edit { it[FLOATING_SWITCHER_ORIENTATION] = orientation }
    }

    val floatingSwitcherItems: Flow<List<String>> = context.dataStore.data
        .map {
            val raw = it[FLOATING_SWITCHER_ITEMS] ?: "chat,ide,terminal,browser,notes,files"
            withNotesSwitcherItem(raw.split(",").map { s -> s.trim() }.filter { s -> s.isNotEmpty() })
        }

    fun getFloatingSwitcherItemsSync(): List<String> {
        val raw = syncPrefs.getString("floating_switcher_items", "chat,ide,terminal,browser,notes,files") ?: "chat,ide,terminal,browser,notes,files"
        return withNotesSwitcherItem(raw.split(",").map { it.trim() }.filter { it.isNotEmpty() })
    }

    /** Lists saved before Notes / Files existed get them at the end, until the user customizes the switcher items themselves. */
    private fun withNotesSwitcherItem(items: List<String>): List<String> {
        val withNotes = if ("notes" in items || syncPrefs.getBoolean("floating_switcher_items_has_notes", false)) items else items + "notes"
        return if ("files" in withNotes || syncPrefs.getBoolean("floating_switcher_items_has_files", false)) withNotes else withNotes + "files"
    }

    suspend fun saveFloatingSwitcherItems(items: List<String>) {
        val raw = items.joinToString(",")
        syncPrefs.edit().putString("floating_switcher_items", raw)
            .putBoolean("floating_switcher_items_has_notes", true).putBoolean("floating_switcher_items_has_files", true).apply()
        context.dataStore.edit { it[FLOATING_SWITCHER_ITEMS] = raw }
    }

    /** Shortcut icons in the chat's top bar, in order ("newchat", "ide", "terminal", "browser", "notes", "files"); may be empty. */
    val chatHeaderItems: Flow<List<String>> = context.dataStore.data
        .map { parseChatHeaderItems(it[CHAT_HEADER_ITEMS] ?: syncPrefs.getString("chat_header_items", "newchat") ?: "newchat") }

    fun getChatHeaderItemsSync(): List<String> =
        parseChatHeaderItems(syncPrefs.getString("chat_header_items", "newchat") ?: "newchat")

    private fun parseChatHeaderItems(raw: String): List<String> =
        raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    suspend fun saveChatHeaderItems(items: List<String>) {
        val raw = items.joinToString(",")
        syncPrefs.edit().putString("chat_header_items", raw).apply()
        context.dataStore.edit { it[CHAT_HEADER_ITEMS] = raw }
    }

    val floatingSwitcherAutoCollapseSec: Flow<Int> = context.dataStore.data
        .map { it[FLOATING_SWITCHER_AUTO_COLLAPSE_SEC] ?: 0 }

    fun getFloatingSwitcherAutoCollapseSecSync(): Int = syncPrefs.getInt("floating_switcher_auto_collapse_sec", 0)

    suspend fun saveFloatingSwitcherAutoCollapseSec(sec: Int) {
        syncPrefs.edit().putInt("floating_switcher_auto_collapse_sec", sec).apply()
        context.dataStore.edit { it[FLOATING_SWITCHER_AUTO_COLLAPSE_SEC] = sec }
    }

    val floatingSwitcherPosX: Flow<Float> = context.dataStore.data
        .map { it[FLOATING_SWITCHER_POS_X] ?: 0.95f }

    val floatingSwitcherPosY: Flow<Float> = context.dataStore.data
        .map { it[FLOATING_SWITCHER_POS_Y] ?: 0.50f }

    fun getFloatingSwitcherPositionSync(): Pair<Float, Float> {
        val x = syncPrefs.getFloat("floating_switcher_pos_x", 0.95f)
        val y = syncPrefs.getFloat("floating_switcher_pos_y", 0.50f)
        return Pair(x, y)
    }

    fun saveFloatingSwitcherPositionSync(x: Float, y: Float) {
        syncPrefs.edit()
            .putFloat("floating_switcher_pos_x", x)
            .putFloat("floating_switcher_pos_y", y)
            .apply()
    }

    suspend fun saveFloatingSwitcherPosition(x: Float, y: Float) {
        saveFloatingSwitcherPositionSync(x, y)
        context.dataStore.edit {
            it[FLOATING_SWITCHER_POS_X] = x
            it[FLOATING_SWITCHER_POS_Y] = y
        }
    }

    val isFloatingDiagnosticsEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_FLOATING_DIAGNOSTICS_ENABLED] ?: false }

    fun getFloatingDiagnosticsEnabledSync(): Boolean = syncPrefs.getBoolean("is_floating_diagnostics_enabled", false)

    suspend fun saveFloatingDiagnosticsEnabled(enabled: Boolean) {
        syncPrefs.edit().putBoolean("is_floating_diagnostics_enabled", enabled).apply()
        context.dataStore.edit { it[IS_FLOATING_DIAGNOSTICS_ENABLED] = enabled }
    }

    val isNetworkInspectorEnabled: Flow<Boolean> = callbackFlow {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "is_network_inspector_enabled") {
                trySend(getNetworkInspectorEnabledSync())
            }
        }
        syncPrefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(getNetworkInspectorEnabledSync())
        awaitClose { syncPrefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    fun getNetworkInspectorEnabledSync(): Boolean = syncPrefs.getBoolean("is_network_inspector_enabled", false)

    fun saveNetworkInspectorEnabledSync(enabled: Boolean) {
        ai.antigem.data.remote.inspector.NetworkInspectorManager.isEnabled = enabled
        syncPrefs.edit().putBoolean("is_network_inspector_enabled", enabled).commit()
    }

    suspend fun saveNetworkInspectorEnabled(enabled: Boolean) {
        saveNetworkInspectorEnabledSync(enabled)
        context.dataStore.edit { it[IS_NETWORK_INSPECTOR_ENABLED] = enabled }
    }

    val isFloatingNetworkInspectorEnabled: Flow<Boolean> = callbackFlow {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "is_floating_network_inspector_enabled") {
                trySend(getFloatingNetworkInspectorEnabledSync())
            }
        }
        syncPrefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(getFloatingNetworkInspectorEnabledSync())
        awaitClose { syncPrefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    fun getFloatingNetworkInspectorEnabledSync(): Boolean = syncPrefs.getBoolean("is_floating_network_inspector_enabled", false)

    fun saveFloatingNetworkInspectorEnabledSync(enabled: Boolean) {
        ai.antigem.data.remote.inspector.NetworkInspectorManager.isFloatingBubbleEnabled = enabled
        syncPrefs.edit().putBoolean("is_floating_network_inspector_enabled", enabled).commit()
    }

    suspend fun saveFloatingNetworkInspectorEnabled(enabled: Boolean) {
        saveFloatingNetworkInspectorEnabledSync(enabled)
        context.dataStore.edit { it[IS_FLOATING_NETWORK_INSPECTOR_ENABLED] = enabled }
    }

    val securityToken: Flow<String> = context.dataStore.data.map {
        it[SECURITY_TOKEN] ?: getSecurityTokenSync()
    }

    fun getSecurityTokenSync(): String {
        var token = syncPrefs.getString("security_token", null)
        if (token.isNullOrBlank() || token.length != TOKEN_LENGTH) {
            token = generateRandomToken()
            syncPrefs.edit().putString("security_token", token).apply()
        }
        currentSecurityToken = token
        return token
    }

    suspend fun saveSecurityToken(token: String) {
        val clean = token.trim()
        val validToken = if (clean.length == TOKEN_LENGTH) clean else generateRandomToken()
        syncPrefs.edit().putString("security_token", validToken).apply()
        currentSecurityToken = validToken
        context.dataStore.edit { it[SECURITY_TOKEN] = validToken }
    }

    fun getDefaultBridgeBinaryPath(): String =
        DEFAULT_BRIDGE_BINARY_PATH

    fun getDefaultAgyBinaryPath(): String =
        DEFAULT_AGY_BINARY_PATH

    val agyBridgeBinaryPath: Flow<String> = context.dataStore.data.map {
        it[AGY_BRIDGE_BINARY_PATH] ?: getAgyBridgeBinaryPathSync()
    }

    fun getAgyBridgeBinaryPathSync(): String =
        syncPrefs.getString("agy_bridge_binary_path", getDefaultBridgeBinaryPath()) ?: getDefaultBridgeBinaryPath()

    suspend fun saveAgyBridgeBinaryPath(path: String) {
        val trimmed = path.trim().ifBlank { getDefaultBridgeBinaryPath() }
        syncPrefs.edit().putString("agy_bridge_binary_path", trimmed).apply()
        context.dataStore.edit { it[AGY_BRIDGE_BINARY_PATH] = trimmed }
    }

    val agyBinaryPath: Flow<String> = context.dataStore.data.map {
        it[AGY_BINARY_PATH] ?: getAgyBinaryPathSync()
    }

    fun getAgyBinaryPathSync(): String =
        syncPrefs.getString("agy_binary_path", getDefaultAgyBinaryPath()) ?: getDefaultAgyBinaryPath()

    suspend fun saveAgyBinaryPath(path: String) {
        val trimmed = path.trim().ifBlank { getDefaultAgyBinaryPath() }
        syncPrefs.edit().putString("agy_binary_path", trimmed).apply()
        context.dataStore.edit { it[AGY_BINARY_PATH] = trimmed }
    }

    fun getDefaultClaudeBinaryPath(): String =
        DEFAULT_CLAUDE_BINARY_PATH

    fun getClaudeBinaryPathSync(): String =
        syncPrefs.getString("claude_binary_path", getDefaultClaudeBinaryPath()) ?: getDefaultClaudeBinaryPath()

    suspend fun saveClaudeBinaryPath(path: String) {
        val trimmed = path.trim().ifBlank { getDefaultClaudeBinaryPath() }
        syncPrefs.edit().putString("claude_binary_path", trimmed).apply()
        context.dataStore.edit { it[CLAUDE_BINARY_PATH] = trimmed }
    }

    fun getDefaultOpenCodeBinaryPath(): String =
        DEFAULT_OPENCODE_BINARY_PATH

    fun getOpenCodeBinaryPathSync(): String =
        syncPrefs.getString("opencode_binary_path", getDefaultOpenCodeBinaryPath()) ?: getDefaultOpenCodeBinaryPath()

    fun saveOpenCodeBinaryPath(path: String) {
        syncPrefs.edit().putString("opencode_binary_path", path.trim().ifBlank { getDefaultOpenCodeBinaryPath() }).apply()
    }

    fun getDefaultCodexBinaryPath(): String =
        DEFAULT_CODEX_BINARY_PATH

    fun getCodexBinaryPathSync(): String =
        syncPrefs.getString("codex_binary_path", getDefaultCodexBinaryPath()) ?: getDefaultCodexBinaryPath()

    fun saveCodexBinaryPath(path: String) {
        syncPrefs.edit().putString("codex_binary_path", path.trim().ifBlank { getDefaultCodexBinaryPath() }).apply()
    }

    val hasSeenTerminalLauncherOnboarding: Flow<Boolean> = context.dataStore.data.map {
        it[HAS_SEEN_TERMINAL_LAUNCHER_ONBOARDING] ?: false
    }

    suspend fun setHasSeenTerminalLauncherOnboarding(seen: Boolean) {
        context.dataStore.edit { it[HAS_SEEN_TERMINAL_LAUNCHER_ONBOARDING] = seen }
    }

    val terminalLauncherStyle: Flow<String> = context.dataStore.data.map {
        it[TERMINAL_LAUNCHER_STYLE] ?: "ANTITERM"
    }

    suspend fun setTerminalLauncherStyle(style: String) {
        context.dataStore.edit { it[TERMINAL_LAUNCHER_STYLE] = style }
    }

    val isTerminalLauncherEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[IS_TERMINAL_LAUNCHER_ENABLED] ?: false
    }

    /**
     * The separate terminal icon became opt-in. Returns true exactly once per install (and marks it done), so existing
     * installs get the icon switched off one time and are asked again, with "hidden" preselected.
     */
    fun takeTerminalLauncherResetSync(): Boolean {
        if (syncPrefs.getBoolean("terminal_launcher_optin_reset_v1", false)) return false
        syncPrefs.edit().putBoolean("terminal_launcher_optin_reset_v1", true).apply()
        return true
    }

    suspend fun setTerminalLauncherEnabled(enabled: Boolean) {
        context.dataStore.edit { it[IS_TERMINAL_LAUNCHER_ENABLED] = enabled }
    }

    suspend fun clearAuth() {
        context.dataStore.edit { prefs ->
            prefs.remove(ACCESS_TOKEN)
            prefs.remove(REFRESH_TOKEN)
            prefs.remove(EXPIRES_AT)
            prefs.remove(USER_EMAIL)
        }
    }
}
