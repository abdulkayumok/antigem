package ai.antigem.data.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import ai.antigem.MainActivity
import ai.antigem.R
import ai.antigem.data.local.LocalTerminalManager
import ai.antigem.ui.bubble.FloatingChatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

open class AntiGemService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var currentSessionCount: Int = 0
    /** Run panel / IDE commands still running (they keep this service, and so the app, alive). */
    private var currentRunCount: Int = 0

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val TAG = "AntiGemService"
        private const val CHANNEL_ID = "antigem_termux_service_channel"
        private const val NOTIFICATION_ID = 1337

        const val ACTION_WAKE_LOCK = "ai.antigem.service_wake_lock"
        const val ACTION_WAKE_UNLOCK = "ai.antigem.service_wake_unlock"
        const val ACTION_STOP_SERVICE = "ai.antigem.service_stop"

        fun start(context: Context) {
            val intent = Intent(context, ai.antigem.app.TermuxService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ai.antigem.app.TermuxService::class.java).setAction(ACTION_STOP_SERVICE)
            context.startService(intent)
        }

        fun requestDisableBatteryOptimizations(context: Context) {
            try {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(context.packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:${context.packageName}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed requesting battery optimization ignore: ${e.message}")
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        runStartForeground()
        observeTerminalSessions()
        ai.antigem.data.remote.AndroidLocalBridgeServer.instance.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when {
            action == ACTION_STOP_SERVICE || action?.endsWith(".service_stop") == true -> {
                Log.d(TAG, "ACTION_STOP_SERVICE intent received")
                actionStopService()
                return START_NOT_STICKY
            }
            action == ACTION_WAKE_LOCK || action?.endsWith(".service_wake_lock") == true -> {
                Log.d(TAG, "ACTION_WAKE_LOCK intent received")
                actionAcquireWakeLock()
            }
            action == ACTION_WAKE_UNLOCK || action?.endsWith(".service_wake_unlock") == true -> {
                Log.d(TAG, "ACTION_WAKE_UNLOCK intent received")
                actionReleaseWakeLock()
            }
            else -> {
                runStartForeground()
            }
        }

        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        actionReleaseWakeLock()

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    private fun observeTerminalSessions() {
        serviceScope.launch {
            kotlinx.coroutines.flow.combine(
                LocalTerminalManager.sessions,
                ai.antigem.data.run.RunManager.runs
            ) { sessions, runs ->
                sessions.size to runs.count { it.status == ai.antigem.data.run.RunStatus.RUNNING }
            }.collect { (sessions, running) ->
                currentSessionCount = sessions
                currentRunCount = running
                updateNotification()
            }
        }
    }

    private fun runStartForeground() {
        setupNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    private fun setupNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "AntiGem Terminal & Execution Service"
            val descriptionText = "Terminal sessions and background execution"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notificationManager?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val wakeLockHeld = wakeLock != null

        val sessionText = "$currentSessionCount " + (if (currentSessionCount == 1) "session" else "sessions") +
            (if (currentRunCount > 0) " · $currentRunCount running" else "")
        val notificationText = if (wakeLockHeld) "$sessionText (wake lock held)" else sessionText

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Float Window Action
        val floatIntent = Intent(this, FloatingChatActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        }
        val floatPendingIntent = PendingIntent.getActivity(
            this, 3, floatIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Exit action
        val exitIntent = Intent(this, ai.antigem.app.TermuxService::class.java).setAction(ACTION_STOP_SERVICE)
        val exitPendingIntent = PendingIntent.getService(
            this, 1, exitIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // WakeLock toggle action
        val wakeAction = if (wakeLockHeld) ACTION_WAKE_UNLOCK else ACTION_WAKE_LOCK
        val toggleWakeLockIntent = Intent(this, ai.antigem.app.TermuxService::class.java).setAction(wakeAction)
        val wakePendingIntent = PendingIntent.getService(
            this, 2, toggleWakeLockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val wakeActionTitle = if (wakeLockHeld) "Release wakelock" else "Acquire wakelock"
        val wakeActionIcon = if (wakeLockHeld) android.R.drawable.ic_lock_idle_lock else android.R.drawable.ic_lock_lock

        val priority = if (wakeLockHeld) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AntiGem")
            .setContentText(notificationText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setShowWhen(false)
            .setPriority(priority)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Exit", exitPendingIntent)
            .addAction(wakeActionIcon, wakeActionTitle, wakePendingIntent)
            .addAction(android.R.drawable.ic_menu_view, "Float", floatPendingIntent)
            .build()
    }

    @SuppressLint("WakelockTimeout")
    private fun actionAcquireWakeLock() {
        if (wakeLock != null) {
            Log.d(TAG, "Ignoring acquiring WakeLocks since they are already held")
            return
        }

        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "termux:service-wakelock").apply {
                setReferenceCounted(false)
                acquire(60 * 60 * 1000L) // 1-hour maximum timeout
            }
            Log.d(TAG, "Acquired partial WakeLock (1-hour timeout)")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to acquire WakeLock: ${e.message}")
        }

        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "termux").apply {
                setReferenceCounted(false)
                acquire()
            }
            Log.d(TAG, "Acquired high-perf WifiLock")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to acquire WifiLock: ${e.message}")
        }

        requestDisableBatteryOptimizations(this)
        updateNotification()
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this@AntiGemService, "Wake lock activated for 1 hour", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actionReleaseWakeLock() {
        if (wakeLock == null && wifiLock == null) {
            Log.d(TAG, "Ignoring releasing WakeLocks since none are already held")
            return
        }

        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
            wakeLock = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing WakeLock: ${e.message}")
        }

        try {
            wifiLock?.let {
                if (it.isHeld) it.release()
            }
            wifiLock = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing WifiLock: ${e.message}")
        }

        updateNotification()
        Log.d(TAG, "WakeLocks released successfully")
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this@AntiGemService, "Wake lock released", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actionStopService() {
        Log.d(TAG, "actionStopService: Force-killing all background processes and stopping service")
        actionReleaseWakeLock()
        try {
            ai.antigem.data.local.LocalServerManager.forceKillAll()
        } catch (e: Exception) {
            Log.w(TAG, "Error force killing server manager: ${e.message}")
        }
        try {
            LocalTerminalManager.closeAll()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing terminal sessions: ${e.message}")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
        android.os.Process.killProcess(android.os.Process.myPid())
        kotlin.system.exitProcess(0)
    }
}
